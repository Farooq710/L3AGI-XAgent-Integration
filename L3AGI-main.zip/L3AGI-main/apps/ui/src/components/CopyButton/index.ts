export { default } from './CopyButton'
