export const useSuggestions = () => {
  return { chatSuggestions: [] }
}
