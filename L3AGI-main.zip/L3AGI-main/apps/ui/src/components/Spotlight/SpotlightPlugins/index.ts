export { default } from './SpotlightPlugins'
