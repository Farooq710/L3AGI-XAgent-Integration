export { default } from './Spotlight'
