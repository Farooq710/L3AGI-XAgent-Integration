export default {
  backgroundColor: '#4CA6F8',
  // padding: '5px 0px 3px 1px ',
  padding: '5px 0',
  width: 'fit-content',
  height: 'fit-content',
}
