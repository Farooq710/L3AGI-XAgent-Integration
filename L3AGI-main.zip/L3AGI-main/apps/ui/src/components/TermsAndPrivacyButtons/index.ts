export { default } from './TermsAndPrivacyButtons'
