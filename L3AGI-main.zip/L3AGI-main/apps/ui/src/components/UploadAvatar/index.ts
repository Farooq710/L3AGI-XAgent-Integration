export { default } from './UploadAvatar'
