// import { useContext } from 'react'
// import { AuthContext } from 'contexts'
import { StyledFooter } from './LayoutStyle'

// import AvatarDropDown from 'components/AvatarDropDown'
// import styled from 'styled-components'

const Footer = () => {
  // const { user } = useContext(AuthContext)
  // const { first_name } = user
  return (
    <StyledFooter id='main_footer'>
      {/* <StyledAvatarContainer>
        <AvatarDropDown />
        <StyledFirstName>{first_name}</StyledFirstName>
      </StyledAvatarContainer> */}
    </StyledFooter>
  )
}

export default Footer

// const StyledFirstName = styled.span`
//   @media (max-width: 1000px) {
//     display: none;
//   }
// `
