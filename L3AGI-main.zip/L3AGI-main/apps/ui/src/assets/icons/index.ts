import starsIcon from './stars_icon.svg'
import closeIcon from './CloseIcon.svg'
import editIcon from './edit_icon.svg'
import enterIcon from './enter_icon.svg'

export { starsIcon, closeIcon, editIcon, enterIcon }
